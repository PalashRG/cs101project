Year: 2015

Course: CS101

Group number: 344

Project Title: Arkanoid (Brick game)


Member1 Name: Palash Gajjar (Leader)      

Member1 Roll Number: 14D17001


Member2 Name: Suraj Naik

Member2 Roll Number: 14D170020


Member3 Name: Ashwin Munjewar
Member3 Roll Number: 140110040


Member4 Name: Raj Verma

Member4 Roll Number: 14D110010


YouTube Video Link: https://youtu.be/Zy5CTQ3Xhdg